ZAYROTH AI — static public prototype

Upload index.html to the root of a public GitHub repository, then enable GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root).

This first version has no live AI provider and no API key. It includes prepared demo lessons in English, Assamese and Hindi, a quadratic equation solver, an Ohm's law calculator, built-in diagrams and browser speech. It does not store or send your typed questions.

Never paste a secret API key into index.html or a public repository. Add a server-side AI provider only after a parent/guardian reviews the provider's current terms and privacy obligations for the intended student audience.
